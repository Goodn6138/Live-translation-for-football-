# 🎙️ Chinese → English Speech Translator

This project fetches **Chinese audio from a URL**, uses **Soniox** to transcribe & translate, and overlays English subtitles on a web page.

## 🚀 Features
- Paste any audio URL (WAV, MP3).
- FastAPI backend with Soniox transcription.
- Simple frontend overlay (HTML + JS).
- Secure API key storage via `.env`.

---

## 🔧 Setup

### 1. Clone repo
```bash
git clone https://github.com/YOUR-USERNAME/speech-translator.git
cd speech-translator/backend
```

### 2. Install deps
```bash
pip install -r requirements.txt
```

### 3. Add API key
Create `.env` in `/backend`:
```
SONIOX_API_KEY=your_real_key_here
```

### 4. Run backend
```bash
uvicorn app:app --reload --port 8000
```

### 5. Run frontend
Open `frontend/index.html` in a browser.

---

## 🌍 Deployment
- Backend → Render / Railway / AWS Lambda
- Frontend → Vercel / Netlify (set backend API URL in `index.html`)
